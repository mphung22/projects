import Foundation

struct BrowAnswers: FormAnswers {
    var fullName = ""
    var phone = ""
    var dateOfBirth: Date?
    var idNumber = ""
    var serviceDate = Date()
    /// Single service from records saved before several services could be chosen.
    var serviceID = ""
    /// Optional so records saved by the older version still open.
    var serviceIDs: Set<String>? = []
    var technician = ""
    /// Items chosen from the price list (id → quantity). Optional so records saved by older versions still open.
    var priceSelection: PriceSelection?

    var contraindications: Set<String> = []
    var noContraindications = false

    var ackInformed = false
    /// "No contraindications" — or, if any were ticked, "discussed with technician".
    var ackHealth = false
    /// "agree" / "disagree" / "" (not answered)
    var photoConsent = ""

    var customerSignature: Data?
    var technicianSignature: Data?

    var selectedServices: Set<String> {
        get { serviceIDs ?? (serviceID.isEmpty ? [] : [serviceID]) }
        set { serviceIDs = newValue }
    }
    var prices: PriceSelection {
        get { priceSelection ?? [:] }
        set { priceSelection = newValue }
    }
    var priceLines: [PriceLine] { SerenContent.priceGroups.lines(for: prices) }
    var total: PriceTotal { SerenContent.priceGroups.total(for: prices) }
    /// Everything chosen, old-style ticks and price-list items, for picking the info and aftercare to show.
    var categoryIDs: Set<String> { selectedServices.union(prices.keys) }
    /// Chosen services: price-list items, or the old-style ticks on older records.
    var serviceLabels: [L] {
        priceLines.isEmpty ? SerenContent.legacyServices.labels(for: selectedServices) : priceLines.map(\.label)
    }
    var contraindicationLabels: [L] { SerenContent.contraindications.labels(for: contraindications) }
    var healthAckText: L { contraindications.isEmpty ? SerenContent.ackNoContraindications : SerenContent.ackDiscussed }

    /// Anything still required before the form can be submitted.
    var missingItems: [L] {
        var missing: [L] = []
        if fullName.trimmed.isEmpty { missing.append(SerenContent.fullName) }
        if priceLines.isEmpty { missing.append(SerenContent.registeredService) }
        if contraindications.isEmpty && !noContraindications {
            missing.append(L("Chống chỉ định: đánh dấu mục phù hợp hoặc “Không có”",
                             "Contraindications: tick what applies or “None of the above”"))
        }
        if !ackInformed || !ackHealth {
            missing.append(L("Đánh dấu ô đồng ý các cam kết", "Tick the box to agree to the statements"))
        }
        if photoConsent.isEmpty { missing.append(SerenContent.photoQuestion) }
        if customerSignature == nil { missing.append(SerenContent.customerSignature) }
        return missing
    }

    // MARK: FormAnswers

    var customerName: String { fullName }
    var customerPhone: String { phone }
    var serviceSummary: String {
        let names = serviceLabels.map(\.en).joined(separator: ", ")
        return priceLines.isEmpty ? names : names + " · " + total.text
    }

    var healthAlert: String? {
        contraindicationLabels.isEmpty ? nil : contraindicationLabels.map(\.both).joined(separator: " • ")
    }

    static let csvHeader = [
        "Full name", "Phone", "Date of birth", "ID/Passport", "Service date", "Service", "Total (VND)",
        "Technician", "Contraindications", "Photo consent",
    ]

    var csvRow: [String] {
        [
            fullName, phone, dateOfBirth.dayString, idNumber, Formatters.date.string(from: serviceDate),
            priceLines.isEmpty ? serviceSummary : SerenContent.priceGroups.csvItems(for: prices),
            priceLines.isEmpty ? "" : total.text,
            technician,
            contraindicationLabels.map(\.en).joined(separator: "; "),
            photoConsent == "agree" ? "Agree" : "Do not agree",
        ]
    }
}
